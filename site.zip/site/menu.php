	<div class="header">
		<a href="index.php">Головна</a>
		<a href="puzzle.php">Загадки</a>
		<a href="guess.php">Здогадайка</a>
		<a href="guessMultiplayer.php">Здогадайка на двох</a>
		<a href="passwordsGenerate.php">Генератор паролів</a>
	</div>